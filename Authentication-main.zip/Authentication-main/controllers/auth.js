const jwt = require('jsonwebtoken');
const mysql = require('mysql2');
const db = require('../model/db');
const jwt = require('jsonwebtoken');
const db = require('../config/db');
const bcrypt = require('bcryptjs');
const { promisify } = require('util');

exports.login = async (req, res, next) => {
  const { email, password } = req.body;

  // 1) Kullanıcının e-posta adresini kontrol edin
  db.query('SELECT * FROM users WHERE email = ?', [email], async (error, results) => {
    if (error) {
      console.error("Database query error:", error);
      return res.status(500).render("login", {
        message: 'Internal server error'
      });
    }

    // Kullanıcı bulunamazsa hata mesajı gönder
    if (!results || results.length === 0) {
      return res.status(401).render("login", {
        message: 'Email veya şifre yanlış!'
      });
    }

    // 2) Şifreyi karşılaştır
    const user = results[0];
    const isPasswordMatch = await bcrypt.compare(password, user.password);

    if (!isPasswordMatch) {
      return res.status(401).render("login", {
        message: 'Email veya şifre yanlış!'
      });
    }

    // 3) Token oluştur ve çerez olarak gönder
    const id = user.id;
    const token = jwt.sign({ id }, process.env.JWT_SECRET, {
      expiresIn: process.env.JWT_EXPIRES_IN
    });

    const cookieOptions = {
      expires: new Date(
        Date.now() + process.env.JWT_COOKIE_EXPIRES_IN * 24 * 60 * 60 * 1000
      ),
      httpOnly: true,
      secure: process.env.NODE_ENV === 'production'
    };

    res.cookie('jwt', token, cookieOptions);

    // Giriş başarılı, kullanıcıyı yönlendirin
    res.status(200).redirect('/');
  });
};

exports.register = (req, res) => {
  console.log(req.body);
  const { name, email, password, passwordConfirm } = req.body;

  // 2) Check if user exists && password is correct
  db.start.query('SELECT email FROM users WHERE email = ?', [email], async (error, results) => {
    if(error) {
      console.log(error)
    }

    if(results.length > 0 ) {
      return res.render('register', {
                message: 'That Email has been taken'
              });
    } else if(password !== passwordConfirm) {
      return res.render('register', {
        message: 'Passwords do not match'
      });
    }
      
    let hashedPassword = await bcrypt.hash(password, 8);
    console.log(hashedPassword);

    db.start.query('INSERT INTO users SET ?', { name, email, password: hashedPassword }, (error, result) => {
      if (error) {
        console.error("Error inserting user:", error);
        return res.status(500).render("register", {
          message: 'Internal server error'
        });
      }
    
      const id = result.insertId;
      const token = jwt.sign({ id }, process.env.JWT_SECRET, {
        expiresIn: process.env.JWT_EXPIRES_IN
      });
      const cookieOptions = {
        expires: new Date(
          Date.now() + process.env.JWT_COOKIE_EXPIRES_IN * 24 * 60 * 60 * 1000
        ),
        httpOnly: true
      };
      res.cookie('jwt', token, cookieOptions);
      res.status(201).redirect("/");
      
    });
  });
};

// Only for rendered pages, no errors!
exports.isLoggedIn = async (req, res, next) => {
  console.log(req.cookies);
  if (req.cookies.jwt) {
    try {
      // 1) verify token
      const decoded = await promisify(jwt.verify)(
        req.cookies.jwt,
        process.env.JWT_SECRET
      );

      console.log("decoded");
      console.log(decoded);

      // 2) Check if user still exists
      db.start.query('SELECT email FROM users WHERE email = ?', [email], async (error, results) => {
        if (error) {
          console.error("Database query error:", error);
          return res.status(500).render('register', {
            message: 'Internal server error'
          });
        }
      
        if (!results || results.length === 0) {
          // User not found or query failed
          return res.render('register', {
            message: 'That Email has been taken'
          });
        }
      });
    } catch (err) {
      return next();
    }
  } else {
    next();
  }
};

exports.logout = (req, res) => {
  res.cookie('jwt', 'loggedout', {
    expires: new Date(Date.now() + 10 * 1000),
    httpOnly: true
  });
  res.status(200).redirect("/");
};